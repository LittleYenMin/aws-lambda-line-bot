from linebot import (
    LineBotApi, WebhookHandler
)
from linebot.exceptions import (
    InvalidSignatureError
)
from linebot.models import (
    MessageEvent, TextMessage, TextSendMessage,
)

import logging

logger = logging.getLogger()
logger.setLevel(logging.ERROR)

line_bot_api = LineBotApi('YOUR_CHANNEL_ACCESS_TOKEN')
handler = WebhookHandler('YOUR_CHANNEL_SECRET')


def lambda_handler(event, context):
    # get X-Line-Signature header value
    signature = event['headers']['X-Line-Signature']
    # get event body
    body = event['body']
    # handle webhook body
    @handler.add(MessageEvent, message=TextMessage)
    def handle_message(event):
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=event.message.text))
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        {'statusCode': 400, 'body': 'InvalidSignature'}
    return {'statusCode': 200, 'body': 'OK'}